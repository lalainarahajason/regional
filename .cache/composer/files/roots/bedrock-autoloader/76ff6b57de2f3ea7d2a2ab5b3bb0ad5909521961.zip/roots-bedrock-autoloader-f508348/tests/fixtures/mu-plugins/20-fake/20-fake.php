<?php
/**
 * Plugin Name: 0w0
 * Version: 1.0.0
 */

define('fake_OwO', 'loaded');
