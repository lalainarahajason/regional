---
name: Support Question
about: Need guidance/clarification? Get it here

---

Hey, that was actually a bit of a trick, sorry. Please post your question to [StackOverflow](http://stackoverflow.com/questions/tagged/timber) using the Timber tag. To help us keep (or start to keep) the Issues section a bit cleaner, we're going to close support question-ish issues. StackOverflow is the best place for these — thanks!
