<!--
Is this a support or usage question? Please post to Stack Overflow (http://stackoverflow.com/questions/tagged/timber) using the Timber tag.
-->

## Expected behavior
<!-- Please describe what output you expect to see from Timber -->

## Actual behavior
<!-- Please describe what you see instead. Please provide samples of HTML output or screenshots -->

## Steps to reproduce behavior
<!-- Please include complete code samples in-line or linked from [gists](https://gist.github.com/) -->

## What version of WordPress, PHP and Timber are you using?
<!-- Example: WordPress 4.4.1, PHP 5.4, Timber 0.22.5 -->

## How did you install Timber? (for example, from GitHub, Composer/Packagist, WP.org?)
<!-- Example: Upgraded to newest version via plugin updater in WordPress dashboard -->
