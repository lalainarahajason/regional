<?php
	echo 'Panic! at the Disco';
	echo ' from ';
	echo 2015-10;