<?php

class page extends Timber\Post {}
