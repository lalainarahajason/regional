<?php

	class TestTimberDeprecated extends Timber_UnitTestCase {

		function testGetPostByMeta() {
			$this->markTestSkipped('It belongs to the ages now');
		}

		function testGetPostsByMeta() {
			$this->markTestSkipped('It belongs to the ages now');
		}

		function testTwitterify() {
			$this->markTestSkipped('It belongs to the ages now');
		}

	}
