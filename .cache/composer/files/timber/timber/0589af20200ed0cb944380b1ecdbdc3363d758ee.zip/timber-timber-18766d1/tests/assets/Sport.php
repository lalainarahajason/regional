<?php
 class Sport extends \Timber\Post {

	function channel() {
		return 'ESPN';
	}

 } 