<?php

class CustomMenuItemClass extends Timber\MenuItem {

}